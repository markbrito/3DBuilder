convert wood.png -size 2000x1500 wood.png
