#ifndef WEBSERVER_H
#define WEBSERVER_H 
extern "C"
{
  void* startWebserver(void *);
  void* startConnection(void *);
}
#endif
